const { DataTypes } = require("sequelize");
const sequelize = require("../config/db");
const UserAgent = require("./UserAgent");
const LeadStatus = require("./LeadStatus");
const Lead = require("./Leads");


  const LeadHistory = sequelize.define(
    "LeadHistory",
    {
      id: {
        type: DataTypes.INTEGER(11),
        allowNull: false,
        primaryKey: true,
        autoIncrement: true,
      },
   company_id:{
      type:DataTypes.INTEGER,
      allowNull:false,
    },
      lead_id: {
        type: DataTypes.INTEGER(11),
        allowNull: false,
      },

      // Stored as INT in DB (most likely unix timestamp)
      followup_date: {
        type: DataTypes.STRING(50),
        allowNull: true,
        defaultValue: null,
      },

      status_id: {
        type: DataTypes.INTEGER(11),
        allowNull: true,
        defaultValue: null,
      },

      changed_by: {
        type: DataTypes.INTEGER(11),
        allowNull: true,
        defaultValue: null,
      },
      remark:{
        type:DataTypes.STRING(255),
        allowNull:true,
        defaultValue:null,
      },

      created_at: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
      },

      updated_at: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
      },
    },
    {
      tableName: "lead_history",
      timestamps: true,
      createdAt: "created_at",
      updatedAt: "updated_at",
      underscored: true,
    }
  );

LeadHistory.belongsTo(UserAgent, { foreignKey: "changed_by", as: "changedBy" });
LeadHistory.belongsTo(LeadStatus, { foreignKey: "status_id", as: "status" });
LeadHistory.belongsTo(Lead, { foreignKey: "lead_id", as: "lead" });


  module.exports = LeadHistory;

