// models/index.js
const sequelize = require("../config/db");

const Admin = require("./Admin");          // users/admin table
const Lead = require("./Leads");          // leads table
const LeadStatus = require("./LeadStatus");
const LeadSource = require("./LeadSource");
const Agent = require("./UserAgent");     // your agent details table (id,name,contact_no,email,role_id)
const UserRole = require("./UserRole");   // roles table

/* -------------------- Roles -------------------- */

// Role -> Users
UserRole.hasMany(Admin, { foreignKey: "role_id", as: "users" });
Admin.belongsTo(UserRole, { foreignKey: "role_id", as: "role" });

// Role -> Agents (only if Agent has role_id)
UserRole.hasMany(Agent, { foreignKey: "role_id", as: "agents" });
Agent.belongsTo(UserRole, { foreignKey: "role_id", as: "role" });




module.exports = {
  sequelize,
  Admin,
  Lead,
  LeadStatus,
  LeadSource,
  Agent,
  UserRole,
};
