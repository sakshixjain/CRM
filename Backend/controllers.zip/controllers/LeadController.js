const Lead = require("../models/Leads");
const { Op } = require("sequelize");
const Agent = require("../models/UserAgent");
const LeadStatus = require("../models/LeadStatus");

exports.createLead = async (req, res) => {
  try {
    const companyId = req.user?.company_id;

    if (!companyId) {
      return res.status(401).json({
        success: false,
        message: "Unauthorized",
      });
    }

    const {
      name,
      email,
      contact_no,
      contact_no1,
      address,
      state,
      city,
      pincode,
      changed_by,
      case_type,
      source_id,
      assign_to,
      status_id,
      description,
      is_active,
      country,
    } = req.body;

    // Normalize email: treat empty string / whitespace as null so it's optional
    const normalizedEmail =
      email && String(email).trim().length > 0 ? String(email).trim() : null;

    // 🔥 Check duplicate contact_no manually inside same company
    const existingLead = await Lead.findOne({
      where: {
        contact_no: contact_no?.trim(),
        company_id: companyId,
      },
    });

    if (existingLead) {
      return res.status(400).json({
        success: false,
        message: "Contact number already exists",
      });
    }

    // Create lead
    const lead = await Lead.create({
      company_id: companyId,
      name,
      email: normalizedEmail,
      contact_no,
      contact_no1,
      address,
      state,
      city,
      pincode,
      case_type,
      source_id,
      changed_by,
      assign_to,
      status_id,
      description,
      is_active: is_active !== undefined ? is_active : true,
      country: country || "India",
    });

    res.status(201).json({
      success: true,
      data: lead,
      message: "Lead created successfully",
    });
  } catch (error) {
    // Handle unique constraint error (duplicate email)
    if (error.name === "SequelizeUniqueConstraintError") {
      return res.status(400).json({
        success: false,
        message: "Email already exists",
      });
    }

    // Handle validation errors
    if (error.name === "SequelizeValidationError") {
      return res.status(400).json({
        success: false,
        message: error.errors.map((e) => e.message).join(", "),
      });
    }

    res.status(500).json({
      success: false,
      message: error.message || "Error creating lead",
    });
  }
};

exports.getAllLeads = async (req, res) => {
  try {
    const companyId = req.user?.company_id;
    console.log("lead ka data", companyId);
    if (!companyId) {
      return res.status(401).json({
        success: false,
        message: "Unauthorized",
      });
    }

    const {
      page = 1,
      limit = 10,
      status_id,
      is_active,
      search,
      assign_to,
      changed_by,
      source_id,
      case_type,
      city,
      state,
      country,
      sortBy = "createdAt",
      sortOrder = "DESC",

      // ✅ add these
      fromDate,
      toDate,
    } = req.query;

    const offset = (Number(page) - 1) * Number(limit);
    const whereClause = {
      company_id: companyId,
    };

    // Apply filters
    if (status_id) whereClause.status_id = status_id;
    if (is_active !== undefined) whereClause.is_active = is_active === "true";
    if (assign_to) whereClause.assign_to = assign_to;
    if (source_id) whereClause.source_id = source_id;
    if (case_type) whereClause.case_type = case_type;
    if (changed_by) whereClause.changed_by = changed_by;
    if (city) whereClause.city = { [Op.like]: `%${city}%` };
    if (state) whereClause.state = { [Op.like]: `%${state}%` };
    if (country) whereClause.country = { [Op.like]: `%${country}%` };

    // ✅ Date filter (createdAt)
    if (fromDate || toDate) {
      const start = fromDate ? new Date(`${fromDate}T00:00:00.000`) : null;
      const end = toDate ? new Date(`${toDate}T23:59:59.999`) : null;

      whereClause.createdAt = {};
      if (start) whereClause.createdAt[Op.gte] = start;
      if (end) whereClause.createdAt[Op.lte] = end;
    }

    // Search across multiple fields
    if (search) {
      whereClause[Op.or] = [
        { name: { [Op.like]: `%${search}%` } },
        { email: { [Op.like]: `%${search}%` } },
        { contact_no: { [Op.like]: `%${search}%` } },
        { address: { [Op.like]: `%${search}%` } },
        { description: { [Op.like]: `%${search}%` } },
      ];
    }

    const { count, rows } = await Lead.findAndCountAll({
      where: whereClause,
      limit: Number(limit),
      offset,
      order: [[sortBy, String(sortOrder).toUpperCase()]],

      include: [
        {
          model: LeadStatus,
          as: "status",
          attributes: ["id", "name", "color"],
          required: false,
        },
        {
          model: Agent,
          as: "assignedTo",
          attributes: ["id", "name", "email"],
          required: false,
        },
        {
          model: Agent,
          as: "changedBy",
          attributes: ["id", "name", "email"],
          required: false,
        },
      ],
    });

    return res.status(200).json({
      success: true,
      data: rows,
      pagination: {
        total: count,
        page: Number(page),
        limit: Number(limit),
        totalPages: Math.ceil(count / Number(limit)),
      },
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message || "Error fetching leads",
    });
  }
};

exports.getLeadById = async (req, res) => {
  try {
    const companyId = req.user?.company_id;

    if (!companyId) {
      return res.status(401).json({
        success: false,
        message: "Unauthorized",
      });
    }

    const lead = await Lead.findOne({
      where: {
        id: req.params.id,
        company_id: companyId,
      },
      // ✅ FIX: include missing
      include: [
        {
          model: LeadStatus,
          as: "status",
          attributes: ["id", "name", "color"],
          required: false,
        },
        {
          model: Agent,
          as: "assignedTo",
          attributes: ["id", "name", "email"],
          required: false,
        },
        {
          model: Agent,
          as: "changedBy",
          attributes: ["id", "name", "email"],
          required: false,
        },
      ],
    });

    if (!lead) {
      return res.status(404).json({
        success: false,
        message: "Lead not found",
      });
    }

    res.status(200).json({
      success: true,
      data: lead,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message || "Error fetching lead",
    });
  }
};

exports.updateLead = async (req, res) => {
  try {
    const companyId = req.user?.company_id;

    if (!companyId) {
      return res.status(401).json({
        success: false,
        message: "Unauthorized",
      });
    }

    const lead = await Lead.findOne({
      where: {
        id: req.params.id,
        company_id: companyId,
      },
    });

    if (!lead) {
      return res.status(404).json({
        success: false,
        message: "Lead not found",
      });
    }

    const {
      name,
      email,
      contact_no,
      contact_no1,
      address,
      state,
      city,
      pincode,
      source_id,
      status_id,
      assign_to,
      case_type,
      description,
      is_active,
      country,
    } = req.body;

    // ✅ Get logged-in agent ID from middleware
    const agentId = req.user?.id;

    if (!agentId) {
      return res.status(401).json({
        success: false,
        message: "Unauthorized",
      });
    }

    // Duplicate email check inside same company
    if (email && email !== lead.email) {
      const existingLead = await Lead.findOne({
        where: {
          email,
          company_id: companyId,
          id: { [Op.ne]: lead.id },
        },
      });

      if (existingLead) {
        return res.status(400).json({
          success: false,
          message: "Email already exists",
        });
      }
    }

    // Duplicate contact_no check inside same company
    if (contact_no && contact_no !== lead.contact_no) {
      const existingContactLead = await Lead.findOne({
        where: {
          contact_no,
          company_id: companyId,
          id: { [Op.ne]: lead.id },
        },
      });

      if (existingContactLead) {
        return res.status(400).json({
          success: false,
          message: "Contact number already exists",
        });
      }
    }

    await lead.update({
      name: name ?? lead.name,
      email: email ?? lead.email,
      contact_no: contact_no ?? lead.contact_no,
      contact_no1: contact_no1 ?? lead.contact_no1,
      address: address ?? lead.address,
      state: state ?? lead.state,
      city: city ?? lead.city,
      case_type: case_type ?? lead.case_type,
      pincode: pincode ?? lead.pincode,
      source_id: source_id ?? lead.source_id,
      status_id: status_id ?? lead.status_id,
      assign_to: assign_to ?? lead.assign_to,
      description: description ?? lead.description,
      is_active: is_active ?? lead.is_active,
      country: country ?? lead.country,

      // 🔥 Store agent ID in changed_by
      changed_by: agentId,
    });

    // ✅ FIX: you were returning plain `lead` without include
    const updatedLead = await Lead.findOne({
      where: {
        id: lead.id,
        company_id: companyId,
      },
      include: [
        {
          model: LeadStatus,
          as: "status",
          attributes: ["id", "name", "color"],
          required: false,
        },
        {
          model: Agent,
          as: "assignedTo",
          attributes: ["id", "name", "email"],
          required: false,
        },
        {
          model: Agent,
          as: "changedBy",
          attributes: ["id", "name", "email"],
          required: false,
        },
      ],
    });

    res.status(200).json({
      success: true,
      data: updatedLead,
      message: "Lead updated successfully",
    });
  } catch (error) {
    if (error.name === "SequelizeValidationError") {
      return res.status(400).json({
        success: false,
        message: error.errors.map((e) => e.message).join(", "),
      });
    }

    res.status(500).json({
      success: false,
      message: error.message || "Error updating lead",
    });
  }
};

exports.deleteLead = async (req, res) => {
  try {
    const companyId = req.user?.company_id;

    if (!companyId) {
      return res.status(401).json({
        success: false,
        message: "Unauthorized",
      });
    }

    const lead = await Lead.findOne({
      where: {
        id: req.params.id,
        company_id: companyId,
      },
    });

    if (!lead) {
      return res.status(404).json({
        success: false,
        message: "Lead not found",
      });
    }

    await lead.destroy();

    res.status(200).json({
      success: true,
      message: "Lead deleted successfully",
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message || "Error deleting lead",
    });
  }
};