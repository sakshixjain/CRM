const LeadHistory = require("../models/LeadHistory");
const Lead = require("../models/Leads");
const LeadStatus = require("../models/LeadStatus");
const UserAgent = require("../models/UserAgent");
const { Op } = require("sequelize");

exports.followup = async (req, res) => {
  try {
    const companyId = req.user?.company_id;
    const userId = req.user?.id;

    const { id } = req.params;
    const { followup_date, followup_time, status_id, remark } = req.body;

    if (!companyId) {
      return res.status(401).json({
        success: false,
        message: "Unauthorized",
      });
    }

    if (!id || !followup_date || !followup_time) {
      return res.status(400).json({
        success: false,
        message: "lead id, followup_date and followup_time are required",
      });
    }

    if (!userId) {
      return res.status(401).json({
        success: false,
        message: "Unauthorized: user not found (token missing/invalid)",
      });
    }

    const lead = await Lead.findOne({
      where: {
        id,
        company_id: companyId,
      },
    });

    if (!lead) {
      return res.status(404).json({ success: false, message: "Lead not found" });
    }

    // ✅ status remark
    let statusRemark = "";
    if (status_id) {
      const st = await LeadStatus.findOne({
        where: {
          id: Number(status_id),
          company_id: companyId,
        },
      });

      if (!st) {
        return res.status(400).json({ success: false, message: "Invalid status_id" });
      }

      statusRemark = `Status updated to: ${st.name}`;
    }

    const cleanRemark = typeof remark === "string" ? remark.trim() : "";
    const finalRemark = cleanRemark ? cleanRemark : statusRemark;

    const combined = `${followup_date} ${followup_time}`; // "YYYY-MM-DD HH:mm:ss"

    // ✅ IMPORTANT: changed_by MUST exist in agents table
    let changedByAgentId = userId ? Number(userId) : null;

    // ✅ verify agent exists in same company to avoid FK / cross-company issues
    if (changedByAgentId) {
      const agent = await UserAgent.findOne({
        where: {
          id: changedByAgentId,
          company_id: companyId,
        },
      });

      if (!agent) changedByAgentId = null;
    }

    const followup = await LeadHistory.create({
      company_id: companyId,
      lead_id: Number(id),
      followup_date: combined,
      status_id: status_id ? Number(status_id) : null,
      changed_by: changedByAgentId, // ✅ agent id OR null
      remark: finalRemark || null,
    });

    const saved = await LeadHistory.findOne({
      where: {
        id: followup.id,
        company_id: companyId,
      },
      include: [
        {
          model: UserAgent,
          as: "changedBy",
          attributes: ["id", "name", "email"],
          required: false,
        },
        {
          model: LeadStatus,
          as: "status",
          attributes: ["id", "name"],
          required: false,
        },
      ],
    });

    return res.status(201).json({
      success: true,
      message: "Follow-up added successfully",
      followup: saved,
    });
  } catch (error) {
    console.error("Followup Error:", error);
    return res.status(500).json({ success: false, message: "Internal Server Error" });
  }
};

exports.getFollowupsByLead = async (req, res) => {
  try {
    const companyId = req.user?.company_id;
    const { id } = req.params;

    if (!companyId) {
      return res.status(401).json({
        success: false,
        message: "Unauthorized",
      });
    }

    if (!id) {
      return res.status(400).json({ success: false, message: "lead id is required" });
    }

    // ✅ Fetch lead only from same company
    const lead = await Lead.findOne({
      where: {
        id,
        company_id: companyId,
      },
      include: [{ model: LeadStatus, as: "status", attributes: ["id", "name"], required: false }],
    });

    if (!lead) {
      return res.status(404).json({ success: false, message: "Lead not found" });
    }

    // ✅ Followups history
    const rows = await LeadHistory.findAll({
      where: {
        lead_id: Number(id),
        company_id: companyId,
      },
      include: [
        {
          model: UserAgent,
          as: "changedBy",
          attributes: ["id", "name", "email"],
          required: false,
        },
        {
          model: LeadStatus,
          as: "status",
          attributes: ["id", "name"],
          required: false,
        },
      ],
      order: [
        ["followup_date", "DESC"],
        ["id", "DESC"],
      ],
    });

    return res.json({
      success: true,
      lead,
      data: rows,
    });
  } catch (error) {
    console.error("getFollowupsByLead Error:", error);
    return res.status(500).json({ success: false, message: "Internal Server Error" });
  }
};

exports.getAllFollowups = async (req, res) => {
  try {
    const companyId = req.user?.company_id;

    if (!companyId) {
      return res.status(401).json({
        success: false,
        message: "Unauthorized",
      });
    }

    const { from, to, status_id, source_id, changed_by, search } = req.query;

    const whereClause = {
      company_id: companyId,
    };

    if (from && to) {
      whereClause.followup_date = {
        [Op.between]: [`${from} 00:00:00`, `${to} 23:59:59`],
      };
    } else if (from) {
      whereClause.followup_date = { [Op.gte]: `${from} 00:00:00` };
    } else if (to) {
      whereClause.followup_date = { [Op.lte]: `${to} 23:59:59` };
    }

    if (status_id) whereClause.status_id = status_id;
    if (source_id) whereClause.source_id = source_id;
    if (changed_by) whereClause.changed_by = changed_by;

    if (search) {
      whereClause[Op.or] = [
        { remark: { [Op.like]: `%${search}%` } },
        { note: { [Op.like]: `%${search}%` } },
        { "$lead.name$": { [Op.like]: `%${search}%` } },
        { "$lead.email$": { [Op.like]: `%${search}%` } },
        { "$lead.contact_no$": { [Op.like]: `%${search}%` } },
      ];
    }

    const rows = await LeadHistory.findAll({
      where: whereClause,
      include: [
        {
          model: Lead,
          as: "lead",
          attributes: ["id", "name", "email", "contact_no"],
          required: false,
          where: {
            company_id: companyId,
          },
        },
        {
          model: UserAgent,
          as: "changedBy",
          attributes: ["id", "name", "email"],
          required: false,
          where: {
            company_id: companyId,
          },
        },
        {
          model: LeadStatus,
          as: "status",
          attributes: ["id", "name"],
          required: false,
          where: {
            company_id: companyId,
          },
        },
      ],
      order: [["followup_date", "DESC"], ["id", "DESC"]],
      distinct: true,
      subQuery: false,
    });

    return res.json({ success: true, data: rows });
  } catch (error) {
    console.error("getAllFollowups Error:", error);
    return res.status(500).json({ success: false, message: "Internal Server Error" });
  }
};

exports.updateFollowup = async (req, res) => {
  try {
    const companyId = req.user?.company_id;
    const userId = req.user?.id;
    const { id } = req.params;
    const { followup_date, followup_time, status_id, remark } = req.body;

    if (!companyId) {
      return res.status(401).json({
        success: false,
        message: "Unauthorized",
      });
    }

    if (!userId) {
      return res.status(401).json({
        success: false,
        message: "Unauthorized: user not found (token missing/invalid)",
      });
    }

    if (!id) {
      return res.status(400).json({
        success: false,
        message: "Followup id is required",
      });
    }

    // ✅ find followup only from same company
    const existingFollowup = await LeadHistory.findOne({
      where: {
        id,
        company_id: companyId,
      },
    });

    if (!existingFollowup) {
      return res.status(404).json({
        success: false,
        message: "Followup not found",
      });
    }

    // ✅ validate status in same company if provided
    let statusRemark = "";
    let validStatusId = existingFollowup.status_id;

    if (status_id !== undefined && status_id !== null && status_id !== "") {
      const st = await LeadStatus.findOne({
        where: {
          id: Number(status_id),
          company_id: companyId,
        },
      });

      if (!st) {
        return res.status(400).json({
          success: false,
          message: "Invalid status_id",
        });
      }

      validStatusId = Number(status_id);
      statusRemark = `Status updated to: ${st.name}`;
    } else if (status_id === null || status_id === "") {
      validStatusId = null;
    }

    // ✅ build followup datetime
    let combinedFollowupDate = existingFollowup.followup_date;

    if (followup_date || followup_time) {
      const oldDateTime = new Date(existingFollowup.followup_date);

      const oldDate = oldDateTime.toISOString().slice(0, 10);
      const oldTime = oldDateTime.toTimeString().slice(0, 8);

      const finalDate = followup_date || oldDate;
      const finalTime = followup_time || oldTime;

      combinedFollowupDate = `${finalDate} ${finalTime}`;
    }

    const cleanRemark = typeof remark === "string" ? remark.trim() : "";
    const finalRemark =
      cleanRemark ||
      (statusRemark ? statusRemark : existingFollowup.remark);

    // ✅ changed_by should exist in same company agents table
    let changedByAgentId = Number(userId);

    const agent = await UserAgent.findOne({
      where: {
        id: changedByAgentId,
        company_id: companyId,
      },
    });

    if (!agent) {
      changedByAgentId = null;
    }

    await LeadHistory.update(
      {
        followup_date: combinedFollowupDate,
        status_id: validStatusId,
        changed_by: changedByAgentId,
        remark: finalRemark || null,
      },
      {
        where: {
          id,
          company_id: companyId,
        },
      }
    );

    const updatedFollowup = await LeadHistory.findOne({
      where: {
        id,
        company_id: companyId,
      },
      include: [
        {
          model: UserAgent,
          as: "changedBy",
          attributes: ["id", "name", "email"],
          required: false,
        },
        {
          model: LeadStatus,
          as: "status",
          attributes: ["id", "name"],
          required: false,
        },
      ],
    });

    return res.json({
      success: true,
      message: "Followup updated successfully",
      followup: updatedFollowup,
    });
  } catch (error) {
    console.error("updateFollowup Error:", error);
    return res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
};

exports.deleteFollowup = async (req, res) => {
  try {
    const companyId = req.user?.company_id;
    const userId = req.user?.id;
    const { id } = req.params;

    if (!companyId) {
      return res.status(401).json({
        success: false,
        message: "Unauthorized",
      });
    }

    if (!userId) {
      return res.status(401).json({
        success: false,
        message: "Unauthorized: user not found",
      });
    }

    if (!id) {
      return res.status(400).json({
        success: false,
        message: "Followup id is required",
      });
    }

    // ✅ Check followup belongs to same company
    const followup = await LeadHistory.findOne({
      where: {
        id,
        company_id: companyId,
      },
    });

    if (!followup) {
      return res.status(404).json({
        success: false,
        message: "Followup not found",
      });
    }

    // ✅ Delete followup
    await LeadHistory.destroy({
      where: {
        id,
        company_id: companyId,
      },
    });

    return res.json({
      success: true,
      message: "Followup deleted successfully",
    });

  } catch (error) {
    console.error("deleteFollowup Error:", error);
    return res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
};
