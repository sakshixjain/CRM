const { Op } = require("sequelize");

// MODELS
const Admin = require("../models/Admin");
const Agent = require("../models/UserAgent");
const Lead = require("../models/Leads");
const Payment = require("../models/Payment");
const LeadSource = require("../models/LeadSource");
const LeadStatus = require("../models/LeadStatus");

exports.globalSearch = async (req, res) => {
  try {
    const q = String(req.query.q || "").trim();

    if (!q || q.length < 2) {
      return res.json({
        success: true,
        query: q,
        results: {},
      });
    }

    const like = `%${q}%`;

    const [
      admins,
      agents,
      leads,
      payments,
      sources,
      statuses,
    ] = await Promise.all([
      // ADMINS
      Admin.findAll({
        where: {
          [Op.or]: [
            { name: { [Op.like]: like } },
            { email: { [Op.like]: like } },
          ],
        },
        attributes: ["id", "name", "email", "role_id"],
        limit: 5,
      }),

      // AGENTS
      Agent.findAll({
        where: {
          [Op.or]: [
            { name: { [Op.like]: like } },
            { email: { [Op.like]: like } },
            { contact_no: { [Op.like]: like } },
          ],
        },
        attributes: ["id", "name", "email", "contact_no", "role_id"],
        limit: 5,
      }),

      // LEADS
      Lead.findAll({
        where: {
          [Op.or]: [
            { name: { [Op.like]: like } },
            { email: { [Op.like]: like } },
            { contact_no: { [Op.like]: like } },
            { city: { [Op.like]: like } },
          ],
        },
        attributes: ["id", "name", "email", "contact_no", "city", "state", "is_active"],
        limit: 8,
      }),

      // PAYMENTS
      Payment.findAll({
        where: {
          [Op.or]: [
            { lead_name: { [Op.like]: like } },
            { contact_no: { [Op.like]: like } },
            { case_type: { [Op.like]: like } },
            { case_location: { [Op.like]: like } },
          ],
        },
        attributes: [
          "id",
          "lead_name",
          "contact_no",
          "case_type",
          "case_location",
          "total_amount",
          "status",
        ],
        limit: 5,
      }),

   // SOURCES
LeadSource.findAll({
  where: { name: { [Op.like]: like } },
  attributes: ["id", "name"],
  limit: 1,
}),

// STATUSES
LeadStatus.findAll({
  where: { name: { [Op.like]: like } },
  attributes: ["id", "name"],
  limit: 1,
}),

    ]);

    // ✅ ADD PATHS
    const withPath = {
     

      agents: agents.map(a => ({
        ...a.toJSON(),
        path: `/agent`,
      })),

      leads: leads.map(l => ({
        ...l.toJSON(),
        path: `/leads`,
      })),

      payments: payments.map(p => ({
        ...p.toJSON(),
        path: `/payments`,
      })),

      sources: sources.map(s => ({
        ...s.toJSON(),
        path: `/source`,
      })),

      statuses: statuses.map(s => ({
        ...s.toJSON(),
        path: `/status`,
      })),
    };

    return res.json({
      success: true,
      query: q,
      results: withPath,
    });
  } catch (error) {
    console.error("Global search error:", error);
    return res.status(500).json({
      success: false,
      message: error?.message || "Global search failed",
    });
  }
};



